#ifndef _UTIL_
#define _UTIL_
int getRandom(int a, int b);

#endif